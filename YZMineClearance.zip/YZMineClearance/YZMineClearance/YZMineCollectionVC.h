//
//  YZMineCollectionVC.h
//  YZMineClearance
//
//  Created by 韩云智 on 16/7/11.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZMineCollectionVC : UICollectionViewController

- (instancetype)initWithX:(NSUInteger)x Y:(NSUInteger)y count:(NSUInteger)count;

@end
