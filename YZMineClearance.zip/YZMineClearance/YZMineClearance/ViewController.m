//
//  ViewController.m
//  YZMineClearance
//
//  Created by 韩云智 on 16/7/11.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import "ViewController.h"
#import "UIView+SDAutoLayout.h"
#import "JXTAlertView.h"
#import "YZMineCollectionVC.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    if( ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0)) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
        self.modalPresentationCapturesStatusBarAppearance = NO;
    }
    self.title = @"YZ扫雷(纯属娱乐)";
    [self createView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)createView{
    
    UIButton * btn0 = [UIButton new];
    btn0.layer.masksToBounds = YES;
    btn0.layer.cornerRadius = 4;
    [btn0 setTitle:@"9x9" forState:UIControlStateNormal];
    [btn0 setBackgroundColor:[UIColor grayColor]];
    btn0.tag = 100;
    [self.view addSubview:btn0];
    
    UIButton * btn1 = [UIButton new];
    btn1.layer.masksToBounds = YES;
    btn1.layer.cornerRadius = 4;
    [btn1 setTitle:@"16x16" forState:UIControlStateNormal];
    [btn1 setBackgroundColor:[UIColor grayColor]];
    btn1.tag = 101;
    [self.view addSubview:btn1];
    
    UIButton * btn2 = [UIButton new];
    btn2.layer.masksToBounds = YES;
    btn2.layer.cornerRadius = 4;
    [btn2 setTitle:@"16x30" forState:UIControlStateNormal];
    [btn2 setBackgroundColor:[UIColor grayColor]];
    btn2.tag = 102;
    [self.view addSubview:btn2];
    
    UIButton * btn3 = [UIButton new];
    btn3.layer.masksToBounds = YES;
    btn3.layer.cornerRadius = 4;
    [btn3 setTitle:@"自定义" forState:UIControlStateNormal];
    [btn3 setBackgroundColor:[UIColor grayColor]];
    btn3.tag = 103;
    [self.view addSubview:btn3];
    
    [btn0 addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    [btn1 addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    [btn2 addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    [btn3 addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    btn0.sd_layout
    .topSpaceToView(self.view, 20)
    .leftSpaceToView(self.view, 20)
    .widthIs((self.view.bounds.size.width-80)/3)
    .heightIs(btn0.size.width*0.4);
    
    btn1.sd_layout
    .topEqualToView(btn0)
    .leftSpaceToView(btn0, 20)
    .heightRatioToView(btn0,1)
    .widthRatioToView(btn0, 1);
    
    btn2.sd_layout
    .topEqualToView(btn0)
    .leftSpaceToView(btn1, 20)
    .rightSpaceToView(self.view, 20)
    .heightRatioToView(btn0, 1)
    .widthRatioToView(btn0, 1);
    
    btn3.sd_layout
    .topSpaceToView(btn0, 20)
    .leftEqualToView(btn0)
    .rightEqualToView(btn2)
    .heightRatioToView(btn0, 1);
}

- (void)onBtn:(UIButton *)sender{
    switch (sender.tag) {
        case 100:
            [self pushTheGameWithX:9 Y:9 Count:10];
            break;
        case 101:
            [self pushTheGameWithX:16 Y:16 Count:40];
            break;
        case 102:
            [self pushTheGameWithX:16 Y:30 Count:99];
            break;
        case 103:
        {
            [[JXTAlertView sharedAlertView] showAlertViewWithConfirmAction:^(NSString *inputText0, NSString *inputText1, NSString * inputText2) {
                [self pushTheGameWithX:inputText0.integerValue Y:inputText1.integerValue Count:inputText2.integerValue];
            } andReloadAction:nil];
        }
            break;
            
        default:
            break;
    }
}

- (void)pushTheGameWithX:(NSUInteger)x Y:(NSUInteger)y Count:(NSUInteger)count{
    if (count > x*y) {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"输入有误" message:@"地雷个数不能多于方格数量" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil, nil];
        [alert show];
        return;
    }
    
    YZMineCollectionVC * vc = [[YZMineCollectionVC alloc]initWithX:x Y:y count:count];
    vc.title = [NSString stringWithFormat:@"%ld/%ld", x*y, x*y];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
