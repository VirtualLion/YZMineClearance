//
//  YZMineCollectionVC.m
//  YZMineClearance
//
//  Created by 韩云智 on 16/7/11.
//  Copyright © 2016年 YZ. All rights reserved.
//

#import "YZMineCollectionVC.h"

@interface YZMineCollectionVC ()

@property (nonatomic, assign) NSUInteger x;
@property (nonatomic, assign) NSUInteger y;
@property (nonatomic, assign) NSUInteger count;

@property (nonatomic, strong) NSMutableArray * dataSource;

@property (nonatomic, assign) NSUInteger number;

@end

@implementation YZMineCollectionVC

static NSString * const reuseIdentifier = @"Cell";

- (instancetype)initWithX:(NSUInteger)x Y:(NSUInteger)y count:(NSUInteger)count
{
    UICollectionViewFlowLayout * flowLayout = [[UICollectionViewFlowLayout alloc]init];
    flowLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    
    flowLayout.minimumLineSpacing = 0;
    flowLayout.minimumInteritemSpacing = 3;
    flowLayout.sectionInset = UIEdgeInsetsMake(3, 3, 3, 3);
    float mm = ([UIScreen mainScreen].bounds.size.width - x * 3 -6) / x;
    flowLayout.itemSize = CGSizeMake(mm, mm);
    self = [super initWithCollectionViewLayout:flowLayout];
    if (self) {
        self.collectionView.bounces = NO;
        self.collectionView.backgroundColor = [UIColor whiteColor];
        _x = x;
        _y = y;
        _count = count;
        
        _dataSource = [[NSMutableArray alloc]init];
        for (int i = 0; i < _x*_y; i++) {
            [_dataSource addObject:@-1];
        }
        _number = _dataSource.count;
        
        for (int i = 0; i < count; i++) {
            int c = arc4random() % _dataSource.count;
            if ([_dataSource[c] isEqual:@-3]) {
                i--;
            }else {
                [_dataSource setObject:@-3 atIndexedSubscript:c];
            }
        }
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Register cell classes
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
//#warning Incomplete implementation, return the number of sections
    return _y;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
//#warning Incomplete implementation, return the number of items
    return _x;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    // Configure the cell
    
    if (!cell.contentView.subviews.count) {
        UILabel * label = [UILabel new];
        [cell.contentView addSubview:label];
        label.frame = cell.contentView.bounds;
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:label.bounds.size.height];
        label.adjustsFontSizeToFitWidth = YES;
    }
    if ([_dataSource[indexPath.section * _x + indexPath.item] intValue] >= 0) {
        cell.backgroundColor = [UIColor lightGrayColor];
        UILabel * label = cell.contentView.subviews.firstObject;
        label.text = [NSString stringWithFormat:@"%@", _dataSource[indexPath.section * _x + indexPath.item]];
    }else {
        cell.backgroundColor = [UIColor cyanColor];
    }
    
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([_dataSource[indexPath.section * _x + indexPath.item] isEqual:@-3]) {
        
        UICollectionViewCell * cell = [collectionView cellForItemAtIndexPath:indexPath];
        
        cell.backgroundColor = [UIColor redColor];
        
        UILabel * label = cell.contentView.subviews.firstObject;
        label.text = @"*";
        
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:@"You Lose !" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
        
        self.collectionView.userInteractionEnabled = NO;
        return;
    }
    
    [self openTheCellItemAtIndexPath:indexPath];
}

- (void)openTheCellItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell * cell = [self.collectionView cellForItemAtIndexPath:indexPath];
    
    if ([_dataSource[indexPath.section * _x + indexPath.item] intValue] >= 0) {
        return;
    }
    [_dataSource setObject:@(0) atIndexedSubscript:indexPath.section*_x+indexPath.item];
    cell.backgroundColor = [UIColor lightGrayColor];
    _number--;
    self.title = [NSString stringWithFormat:@"%ld/%ld", _number, _dataSource.count];
    
    int a = 0;
    
    NSMutableArray * array = [NSMutableArray array];
    
    if (indexPath.section >= 1 && indexPath.item >=1) {
        NSArray * array0 = [self mineWithItem:indexPath.item - 1 inSection:indexPath.section - 1];
        [array addObject:array0.lastObject];
        if ([array0.firstObject boolValue]) {
            a++;
        }
    }
    
    if (indexPath.section >= 1) {
        NSArray * array1 = [self mineWithItem:indexPath.item inSection:indexPath.section - 1];
        [array addObject:array1.lastObject];
        if ([array1.firstObject boolValue]) {
            a++;
        }
    }
    
    if (indexPath.section >= 1 && indexPath.item <_x-1) {
        NSArray * array2 = [self mineWithItem:indexPath.item + 1 inSection:indexPath.section - 1];
        [array addObject:array2.lastObject];
        if ([array2.firstObject boolValue]) {
            a++;
        }
    }
    
    if (indexPath.item >=1) {
        NSArray * array3 = [self mineWithItem:indexPath.item - 1 inSection:indexPath.section];
        [array addObject:array3.lastObject];
        if ([array3.firstObject boolValue]) {
            a++;
        }
    }
    
    if (indexPath.item <_x-1) {
        NSArray * array4 = [self mineWithItem:indexPath.item + 1 inSection:indexPath.section ];
        [array addObject:array4.lastObject];
        if ([array4.firstObject boolValue]) {
            a++;
        }
    }
    
    if (indexPath.section <_y-1 && indexPath.item >=1) {
        NSArray * array5 = [self mineWithItem:indexPath.item - 1 inSection:indexPath.section + 1];
        [array addObject:array5.lastObject];
        if ([array5.firstObject boolValue]) {
            a++;
        }
    }
    
    if (indexPath.section <_y-1) {
        NSArray * array6 = [self mineWithItem:indexPath.item inSection:indexPath.section + 1];
        [array addObject:array6.lastObject];
        if ([array6.firstObject boolValue]) {
            a++;
        }
    }
    
    if (indexPath.section <_y-1 && indexPath.item <_x-1) {
        NSArray * array7 = [self mineWithItem:indexPath.item + 1 inSection:indexPath.section + 1];
        [array addObject:array7.lastObject];
        if ([array7.firstObject boolValue]) {
            a++;
        }
    }
    
    if (a>0) {
        UILabel * label = cell.contentView.subviews.firstObject;
        label.text = [NSString stringWithFormat:@"%d", a];
        [_dataSource setObject:@(a) atIndexedSubscript:indexPath.section*_x+indexPath.item];
    }else{
        for (NSIndexPath * index in array) {
            [self openTheCellItemAtIndexPath:index];
        }
    }
    
    if (_number <= _count) {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:nil message:@"You Win !" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
        return;
    }
}

- (NSArray *)mineWithItem:(NSInteger)item inSection:(NSInteger)section{
    
    NSIndexPath * indexPath = [NSIndexPath indexPathForItem:item inSection:section];
    
    BOOL set = NO;
    
    if ([_dataSource[indexPath.section * _x + indexPath.item] isEqual:@-3]) {
        set = YES;
    }
    
    return @[@(set), indexPath];
}

#pragma mark <UICollectionViewDelegate>

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/

/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

@end
